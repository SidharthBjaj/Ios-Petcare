//
//  DestinationPin.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-11-17.
//

import Foundation
import MapKit

class DestinationPin: NSObject, MKAnnotation{
    //MARK: - Properties
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var subtitle: String?
    var pinColour = UIColor.systemBlue
    
    
    var mapItem: MKMapItem?{
        guard let location = title else { return nil }
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = location
        return mapItem
    }
    
    init(title: String, coordinate: CLLocationCoordinate2D, subtitle: String?){
        self.title = title
        self.coordinate = coordinate
        self.subtitle = subtitle
    }
    
}
