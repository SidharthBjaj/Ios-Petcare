//
//  Destination.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-11-17.
//

import Foundation

struct Destinations: Codable{
    var data: [Destination]
}
struct Destination: Codable, Hashable {
    var latitude: String
    var longitude: String
}
