//
//  PetServices+CoreDataProperties.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-11-01.
//
//

import Foundation
import CoreData


extension PetServices {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PetServices> {
        return NSFetchRequest<PetServices>(entityName: "PetServices")
    }


    @NSManaged public var duedate: Date
    @NSManaged public var notes: String
    @NSManaged public var serviceInfo: String
    @NSManaged public var petInfo: NSSet?

}

// MARK: Generated accessors for petInfo
extension PetServices {

    @objc(addPetInfoObject:)
    @NSManaged public func addToPetInfo(_ value: PetInfo)

    @objc(removePetInfoObject:)
    @NSManaged public func removeFromPetInfo(_ value: PetInfo)

    @objc(addPetInfo:)
    @NSManaged public func addToPetInfo(_ values: NSSet)

    @objc(removePetInfo:)
    @NSManaged public func removeFromPetInfo(_ values: NSSet)

}

extension PetServices : Identifiable {

}
