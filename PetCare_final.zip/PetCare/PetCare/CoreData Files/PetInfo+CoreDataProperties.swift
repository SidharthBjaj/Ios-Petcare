//
//  PetInfo+CoreDataProperties.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-11-01.
//
//

import Foundation
import CoreData


extension PetInfo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PetInfo> {
        return NSFetchRequest<PetInfo>(entityName: "PetInfo")
    }

    @NSManaged public var email: String
    @NSManaged public var petName: String
    @NSManaged public var petOwner: String
    @NSManaged public var petSize: String
    @NSManaged public var phone: String
    @NSManaged public var petService: NSSet?

}

// MARK: Generated accessors for petService
extension PetInfo {

    @objc(addPetServiceObject:)
    @NSManaged public func addToPetService(_ value: PetServices)

    @objc(removePetServiceObject:)
    @NSManaged public func removeFromPetService(_ value: PetServices)

    @objc(addPetService:)
    @NSManaged public func addToPetService(_ values: NSSet)

    @objc(removePetService:)
    @NSManaged public func removeFromPetService(_ values: NSSet)

}

extension PetInfo : Identifiable {

}
