//
//  PetInfo+CoreDataClass.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-11-01.
//
//

import Foundation
import CoreData

@objc(PetInfo)
public class PetInfo: NSManagedObject {

}
