//
//  PetServices+CoreDataClass.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-11-01.
//
//

import Foundation
import CoreData

@objc(PetServices)
public class PetServices: NSManagedObject {

}
