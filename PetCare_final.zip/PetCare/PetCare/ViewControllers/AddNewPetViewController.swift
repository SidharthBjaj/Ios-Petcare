//
//  AddNewPetViewController.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-10-24.
//

import UIKit

class AddNewPetViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    

//    MARK: - Properties
    var coreDataStack: CoreDataStack!
    var sizePet = "TEACUP : <5LBS"
    var size = ["Teacup : <5 LBS","Toy : 5 - 12 LBS","Small : 12 - 24 LBS","Medium : 24 - 57 LBS", "Big : 57 - 99 LBS"]

    
//    MARK: - Outlets
    
    @IBOutlet var OwnerName: UITextField!
    @IBOutlet var phone: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var petsName: UITextField!
    @IBOutlet weak var sizePicker: UIPickerView!
    
//    Pickerview for selecting size of your pet in adding pet page.
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return size[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return size.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        sizePet = size[row]
    }
    
//MARK: - functions
    
//    Adding function to add pet
    
    @IBAction func savePet(_ sender: UIButton){
    
//        Checking for blank colum and advising customer to enter the details
        
        guard let petDetails = OwnerName.text, !petDetails.isEmpty else {
            showAlert(with: "Please enter your name")
            return
        }
        guard let petphone = phone.text, !petphone.isEmpty else {
            showAlert(with: "Please enter your phone")
            return
        }
        guard let petEmail = email.text, !petEmail.isEmpty else {
            showAlert(with: "Please enter your email")
            return
        }
        guard let petName = petsName.text, !petName.isEmpty else {
            showAlert(with: "Please enter your pets name")
            return
        }
        
//       Adding new pet to coredata after verfication from user.
        
        let newPetInfo = PetInfo(context: coreDataStack.managedContext)
        newPetInfo.petName = petName
        newPetInfo.petOwner = petDetails
        newPetInfo.email = petEmail
        newPetInfo.petSize = sizePet
        newPetInfo.phone = petphone
        
        
//      Applied alert controller to verify the details before adding it to database for any correction as form of alert controller.
        
        let alert = UIAlertController(title: "Alert", message: """
        Please review your info before confirming:

        Name :     \(newPetInfo.petOwner)
        Phone :    \(newPetInfo.phone)
        Email :    \(newPetInfo.email)
        PetName :  \(newPetInfo.petName)
        Size :     \(newPetInfo.petSize)
        """, preferredStyle: .alert)
        
//        Dismisses the alert controller to make hanges if needed.
        
        alert.addAction(UIAlertAction(title: "Edit!", style: .destructive, handler: nil))
        present(alert, animated: true, completion: {
            return
        })
//        Adds information to coredata stack
            
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {action in
            self.coreDataStack.saveContext()
            self.navigationController?.popViewController(animated: true)
        }))
        
        
//        implementing notification to make the user aware about them adding service
        let content = UNMutableNotificationContent()
        content.title = "Hi \(OwnerName.text!), Thank you for choosing PetCare"
        content.body = "Did you schedule appoint for \(petsName.text!) ? We would love to meet our new friend soon!"
        
        let sound = UNNotificationSoundName("timed.wav")
        content.sound = UNNotificationSound(named: sound)
        
        let calendarComponents: Set<Calendar.Component> = [.hour, .minute, .second]
        var date = Calendar.current.dateComponents(calendarComponents, from: Date())
        
        if let minute = date.minute, let hour = date.hour{
            if minute < 59 {
                
//          notification can be delayed by adding the number of minutes after ("minute + X) - where x represents the delay you want after pet  is added to database.
                date.minute = minute + 1
            } else {
                date.hour = hour + 1
                date.minute = 0
            }
        }
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: date, repeats: false)
        
        let request = UNNotificationRequest(identifier: "notification.date.\(UUID().uuidString)", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: {
            error in
            if error != nil {
                print("Error with calendar timer - \(error!.localizedDescription)")
            }
        })
        
//        disabling keyboard if tapped on screen
        
        OwnerName.resignFirstResponder()
        phone.resignFirstResponder()
        email.resignFirstResponder()
        petsName.resignFirstResponder()
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        sizePicker.delegate = self
        sizePicker.dataSource = self
        
//        adding alert notification to notify them about them adding pet to our database
        
        let center = UNUserNotificationCenter.current()
        
        center.requestAuthorization(options: [.alert, .badge,.sound], completionHandler: {
            granted, error in
            
            if granted {
                print("Access has been granted")
            } else {
                print("Access has not been granted")
            }
        })

        
    }
    
    
    
//     MARK: - Show alerts function
    
//    Alert function for any left blank
    func showAlert(with message: String){
        let alert = UIAlertController(title: "Attention", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true)
    }
//    implemented 3rd gesture to dismiss keyboard if clicked on blank area.
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }
}
