//
//  MainPetsViewController.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-10-24.
//

import UIKit

class MainPetsViewController: UITableViewController {

//    MARK: - Properties
    var coreDataStack: CoreDataStack!
    var list: PetInfo!
    var services = [PetServices]()
    
//    date formatter
    var dateFormatter: DateFormatter = {
        let df = DateFormatter()
        df.timeStyle = .short
        df.dateStyle = .medium
        df.doesRelativeDateFormatting = true
        return df
    }()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
//    MARK: - Functions
//  import pets details to main page for accessing pets.
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        guard let petdetails = list.petService as? Set<PetServices> else { return }
        services = Array(petdetails)
        tableView.reloadData()
    }
    
//    MARK: - Functions
    
//    Returning number of sections
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
//    returning the number of service after adding them from the add service page
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return services.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "taskCell", for: indexPath)
        let service = services[indexPath.row]
        cell.textLabel?.text = (service.serviceInfo)
        cell.detailTextLabel?.text = "Due Date: \(dateFormatter.string(from: service.duedate))"
        return cell
    }
    

    
//    Override to support editing the tableView
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            let servicesToDelete = services[indexPath.row]
//          deleting service for individual pets.
            
            list.removeFromPetService(servicesToDelete)
            services.remove(at: indexPath.row)
            
            coreDataStack.saveContext()
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
        else if editingStyle == .insert {
        }
    }
    
    // MARK: - Navigation
    
//     In a storyboard-based application, you will often want to do a little preparation before navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
       
//        editing the selected row
        if segue.identifier == "editPetService"{
            guard let selectedIndexPath = tableView.indexPathForSelectedRow, let destinationVC = segue.destination as? AddNewServicesViewController else {return}
            
//            passing edit information page along with passing the service
            
            destinationVC.editService = services[selectedIndexPath.row]
            destinationVC.passedService = services[selectedIndexPath.row]
            destinationVC.coreDataStack = coreDataStack
            destinationVC.title = "Edit work"
        }
        
        
//       adding new service
        
        else if segue.identifier == "addNewServiceSegue"{
            guard let destinationVC = segue.destination as? AddNewServicesViewController else { return }
                destinationVC.list = list
                destinationVC.coreDataStack = coreDataStack
            }
    }
}

    
