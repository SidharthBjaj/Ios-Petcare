//
//  PetViewController.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-10-24.
//

import UIKit
import CoreData

class PetViewController: UITableViewController {
    
//    MARK: - Properties.
    
    lazy var coreDataStack = CoreDataStack(modelName: "PetCare")
    
    var petInfoPage = [PetInfo]()
    var list: PetServices!

    
//    MARK: - Functions
    
//    Fetch request from coredata for displaying data along with sorting with petname
    func fetchDetails(){
        let fetchRequest: NSFetchRequest<PetInfo> = PetInfo.fetchRequest()
        
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "petName", ascending: true)]
        
        do {
            petInfoPage = try coreDataStack.managedContext.fetch(fetchRequest)
        } catch {
            print("There was an error fetching the taskLists: \(error.localizedDescription)")
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
//    view function to display or load the data and reload the data

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchDetails()
        tableView.reloadData()
        
        let docDirect = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(docDirect
        )
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return petInfoPage.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "taskListCell", for: indexPath)

        let taskList = petInfoPage[indexPath.row]
        // Configure the cell...
        cell.textLabel?.text = "Customer Name: \(taskList.petOwner)"
        cell.detailTextLabel?.text = "Pet: \(taskList.petName) - \(taskList.petSize)"
        return cell
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "addNewPetSegue"{
            guard let destinationVC = segue.destination as?AddNewPetViewController else { return }
            
            destinationVC.coreDataStack = coreDataStack
        } else if segue.identifier == "petServiceSegue"{
            guard  let selectedIndexPath = tableView.indexPathForSelectedRow, let destinationVC = segue.destination as? MainPetsViewController else { return }
            
            let selectedTaskList = petInfoPage[selectedIndexPath.row]
            
            destinationVC.list = selectedTaskList
            destinationVC.coreDataStack = coreDataStack
        } 
    }
}
