//
//  AddNewServicesViewController.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-10-31.
//

import UIKit
import CoreData


class AddNewServicesViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
//    MARK: - Properties
    
    var list: PetInfo!
    var editService: PetServices!
    var coreDataStack: CoreDataStack!
    var passedService: PetServices?
    var service = ["Bathing - $50", "Haircut - $50", "Bathing + Haircut - $85"]
    var defaultService = "Bathing - $50"

//    MARK: - Outlets
    
    @IBOutlet  var date: UIDatePicker!
    @IBOutlet weak var serviceR: UITextField!
    @IBOutlet weak var serviceSelector: UIPickerView!
    
    
//    Picker view to select size
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return service[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return service.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        defaultService = service[row]
    }
    
//    MARK: - Functions
    
    @IBAction func saveService(_ sender: UIButton) {
           
        
        guard let newService = serviceR.text else {
           return
           }
        // implementing edit function
        
        if let tryEdit = editService{
            tryEdit.serviceInfo = defaultService
            tryEdit.notes = newService
            tryEdit.duedate = date.date
        }
        
        //            Adding services to list
            else{
                let newServiceToAdd = PetServices(context: coreDataStack.managedContext)
                   newServiceToAdd.notes = newService
                   newServiceToAdd.serviceInfo = defaultService
                   newServiceToAdd.duedate = date.date
                
                    list.addToPetService(newServiceToAdd)
                }
        
        //           saving data to coredata

           coreDataStack.saveContext()
        
           navigationController?.popViewController(animated: true)
        
//        implementing the gesture feature in the code
        serviceR.resignFirstResponder()
       }
       

       override func viewDidLoad() {
           super.viewDidLoad()

           // Do any additional setup after loading the view.
        serviceSelector.delegate = self
        serviceSelector.dataSource = self
        
//        Passing data for it to be displayed in the selected index page.
        if let passedInfo = passedService{
            serviceR.text = passedInfo.notes
            date.date = passedInfo.duedate
            defaultService = passedInfo.serviceInfo
            for (index,service) in service.enumerated(){
                if service == passedInfo.serviceInfo{
                    serviceSelector.selectRow(index, inComponent: 0, animated: true)
                }
            }
        }
        
//        editing the data
        if let editItem = editService{
            editItem.notes = serviceR.text!
            editItem.duedate = date.date
            editItem.serviceInfo = defaultService
            
            for (index, service) in service.enumerated(){
                if editItem.serviceInfo == service{
                    serviceSelector.selectRow(index, inComponent: 0, animated: true)
                }
            }
        }
       }
        
//MARK: - function
    
//    show alert function if notes is left blank
    
       func showAlert(with message: String){
           let alert = UIAlertController(title: "Attention", message: message, preferredStyle: .alert)
           let action = UIAlertAction(title: "OK", style: .default, handler: nil)
           alert.addAction(action)
           present(alert, animated: true)
       }
    
//    implementing keyboard dismiss on touch
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        textField.resignFirstResponder()
        return true
    }


}
