//
//  InfoViewController.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-11-17.
//

import UIKit
import MapKit

class InfoViewController: UIViewController, MKMapViewDelegate {
//MARK: - Outlets
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var mapkit: MKMapView!
    
//MARK: - Properties
    
    
    var destination: Destination!
    var mapPins = [DestinationPin]()
    var titleName = String()
    var subTitle = "Location"
    var latitude = "42.2507597"
    var longitude = "-83.0253951"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        imageView.layer.cornerRadius = 20
        
        fetchPhotos()
        // Do any additional setup after loading the view.
        
        
        // title and description along with calling methods for map
       
        addPin()
        mapkit.delegate = self
        mapkit.isScrollEnabled = true
        mapkit.isZoomEnabled = true
        
    
    }
    
//    MARK: - FUNCTIONS
    
//    Map pin
    
    //    Adding pin / location to map
        func addPin(){
            guard let latitude = Double(latitude), let longitude = Double(longitude) else { return }

            let coordinateRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: latitude, longitude: longitude), latitudinalMeters: 1000, longitudinalMeters: 1000)

            mapkit.setRegion(coordinateRegion, animated: true)
            let pin = DestinationPin(title: titleName, coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude), subtitle: subTitle)
            mapPins.append(pin)
            mapkit.addAnnotations(mapPins)
        }
    
    // pin annotation to detail view page along with creating and re using it
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if let annotation = annotation as? DestinationPin {
            let identifier = MKMapViewDefaultAnnotationViewReuseIdentifier
            var view: MKPinAnnotationView
            
           
            if let dequedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView {
                dequedView.annotation = annotation
                view = dequedView
            } else {
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                view.canShowCallout = true
                view.pinTintColor = annotation.pinColour
                view.animatesDrop = true
            }
            
            return view
        }
        return nil
    }
    
// api call for displaying different images
    struct APIResponse: Codable{
        let message: URL
    }
    
// link for the api
    let apiString = "https://dog.ceo/api/breeds/image/random"
    
//    fetching random images
    func fetchPhotos(){
        
//        checking for images
        guard let url = URL(string: apiString) else {
            print("Issue resolving images")
            return
        }
//        checking for data parsing
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "Failed")
                return
            }
            
            do {
                let jsonResult = try JSONDecoder().decode(APIResponse.self, from: data)
                DispatchQueue.global().async {
                    if let imageData = try? Data(contentsOf: jsonResult.message){
                        DispatchQueue.main.async {
                            self?.imageView.image = UIImage(data: imageData)
                        }
                    }
                }
            }catch{
                print(error)
            }
        }
        task.resume()
    }
    
}
