//
//  IntroViewController.swift
//  PetCare
//
//  Created by Sidharth  Bajaj on 2021-10-31.
//

import UIKit
import MapKit

class IntroViewController: UIViewController {

//    MARK: - Outlets

    @IBOutlet weak var scheduleButton: UIButton!
    @IBOutlet weak var infoPage: UIBarButtonItem!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var detailText: UITextView!
    var imgNames = ["pet1","pet2","pet3","pet4","pet5","pet6"]
    var img = [UIImage]()


    
    override func viewDidLoad() {
        super.viewDidLoad()

//        array to loop through images added in asset folder.
        for i in 0..<imgNames.count{
            img.append(UIImage(named: imgNames[i])!)
        }
        
        imageView.isUserInteractionEnabled = true
        
//      animating images along with adding visual effects to uiview.
        
        
        imageView.animationImages = img
        imageView.animationDuration = 15
        imageView.startAnimating()
        imageView.layer.cornerRadius = 160
        
        
//        changing radius of borders of image in on initial page.
        
        let longPress = UILongPressGestureRecognizer()
        imageView.addGestureRecognizer(longPress)
        longPress.addTarget(self, action: #selector(handleMenu))
    
        
//        setting radius for button
        
        scheduleButton.layer.cornerRadius = 10
        
//        setting radius for textView
        
        detailText.layer.cornerRadius = 8.0
        
//        importing text material from .txt file
        
        let file = "dogs"
        if let path = Bundle.main.path(forResource: file, ofType: "txt"){
            do {
                let data = try String(contentsOfFile: path, encoding: .utf8)
                let myStrings = data.components(separatedBy: .newlines)
                let text = myStrings.joined(separator: "\n")
                detailText.text = text
                print("\(text)")
            } catch {
                print(error)
            }
        }
    }
    
//    MARK: - functions
    
//    function to add pet
    @IBAction func addPetPage(_ sender: UIButton) {
        self.performSegue(withIdentifier: "addNew", sender: nil)
    }
    
    @IBAction func infoPage(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "infoSeg", sender: nil)
        
    }
    //    changing radius of the image by this radius amount on long click
    func changeRadius(){
        imageView.layer.cornerRadius = 20

    }
    
//    handling long click listener to the file
    @objc func handleMenu(_ gesture: UILongPressGestureRecognizer){
        changeRadius()
    }
}
